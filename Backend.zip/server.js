import express, { urlencoded } from 'express' //"type": "module",
import mongoose from 'mongoose';
import vehiculeRouter from './Routes/VehiculeRoute.js';

const app = express()
const port = 9000
mongoose.set("strictQuery", false);
mongoose.connect('mongodb+srv://next:next@cluster0.w7fib.mongodb.net/upm?retryWrites=true&w=majority', {}, err => {
    if(err) console.log(err)
    console.log('Db Connected')
})

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use('/vehicule', vehiculeRouter)



app.listen(port, () => {
    console.log('Server Running')
})